# system_monitor
Host values come from `HostInspector.kt`. Guest values show "Guest not running" until a guest exists.
