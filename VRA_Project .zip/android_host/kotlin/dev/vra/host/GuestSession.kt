package dev.vra.host

import android.content.Context
import java.io.File

/** One running Linux guest under QEMU (software emulation). Console in/out only. No network. */
object GuestSession {
    private var proc: Process? = null
    private val buf = StringBuilder()
    private var total = 0L

    @Synchronized
    fun running(): Boolean {
        val p = proc ?: return false
        return try {
            p.exitValue()
            false
        } catch (e: IllegalThreadStateException) {
            true
        }
    }

    fun start(ctx: Context): Map<String, Any> {
        if (running()) return mapOf("ok" to true, "msg" to "Guest is already running.")
        val q = GuestManager.qemu(ctx)
        if (!q.isFile) return mapOf("ok" to false, "msg" to "QEMU is not packaged in this build.")
        val kernel = GuestManager.guestFile(ctx, "vmlinuz-virt")
        val initrd = GuestManager.guestFile(ctx, "initramfs-vra")
        if (kernel == null || initrd == null)
            return mapOf("ok" to false, "msg" to "Guest kernel or root filesystem is not packaged in this build.")
        return try {
            val linkDir = GuestManager.prepareLibLinks(ctx)
            val args = listOf(
                "-M", "virt", "-cpu", "cortex-a72", "-m", "256", "-smp", "2", "-accel", "tcg",
                "-kernel", kernel.absolutePath, "-initrd", initrd.absolutePath,
                "-append", "console=ttyAMA0 loglevel=3",
                "-nodefaults", "-display", "none", "-serial", "stdio", "-monitor", "none", "-nic", "none"
            )
            val pb = ProcessBuilder(listOf(q.absolutePath) + args).redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = linkDir.absolutePath + ":" + ctx.applicationInfo.nativeLibraryDir
            val p = pb.start()
            synchronized(this) {
                proc = p
                buf.setLength(0)
                total = 0
            }
            Thread {
                try {
                    val r = p.inputStream.bufferedReader()
                    val cb = CharArray(1024)
                    while (true) {
                        val n = r.read(cb)
                        if (n < 0) break
                        synchronized(this) {
                            buf.append(cb, 0, n)
                            total += n
                            if (buf.length > 200000) buf.delete(0, buf.length - 150000)
                        }
                    }
                } catch (e: Exception) {
                }
            }.start()
            mapOf("ok" to true, "msg" to "Guest starting. First boot can take 2 to 3 minutes.")
        } catch (e: Exception) {
            mapOf("ok" to false, "msg" to "Could not start guest: ${e.message}")
        }
    }

    @Synchronized
    fun poll(since: Long): Map<String, Any> {
        val reset = since > total
        val from = if (reset) 0L else since
        val bufStart = total - buf.length
        val idx = (from - bufStart).coerceIn(0, buf.length.toLong()).toInt()
        return mapOf(
            "text" to buf.substring(idx),
            "total" to total,
            "reset" to reset,
            "running" to running(),
        )
    }

    fun send(line: String): Boolean {
        val p = proc ?: return false
        if (!running()) return false
        return try {
            p.outputStream.write((line + "\n").toByteArray())
            p.outputStream.flush()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun stop() {
        proc?.destroy()
    }
}
