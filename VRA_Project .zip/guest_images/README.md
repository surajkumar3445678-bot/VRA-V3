# Guest images
Place a licensed ARM64 Android image at `<app files>/guest/system.img`.
VRA does not ship Android images or Google apps. Use AOSP/LineageOS builds you are allowed to use.
