import 'package:flutter/services.dart';

class HostBridge {
  static const _ch = MethodChannel('dev.vra/host');

  static Future<Map<dynamic, dynamic>> hostInfo() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('hostInfo')) ?? {};

  /// {installed: bool, imagePath: String, qemuPresent: bool, imageBytes: int}
  static Future<Map<dynamic, dynamic>> guestStatus() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('guestStatus')) ?? {};

  /// {ok: bool, reason: String}
  static Future<Map<dynamic, dynamic>> bootGuest() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('bootGuest')) ?? {};

  /// {ok: bool, output: String}. Runs the packaged QEMU binary; starts no guest.
  static Future<Map<dynamic, dynamic>> qemuSmokeTest() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('qemuSmokeTest')) ?? {};

  /// {ok: bool, output: String}. Boots a small Linux guest and returns its console log.
  static Future<Map<dynamic, dynamic>> kernelTest() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('kernelTest')) ?? {};

  /// {ok: bool, msg: String}. Starts the Linux guest.
  static Future<Map<dynamic, dynamic>> guestStart() async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('guestStart')) ?? {};

  /// {text, total, reset, running}. Console output since [since] characters.
  static Future<Map<dynamic, dynamic>> guestPoll(int since) async =>
      (await _ch.invokeMethod<Map<dynamic, dynamic>>('guestPoll', {'since': since})) ?? {};

  static Future<bool> guestSend(String line) async =>
      (await _ch.invokeMethod<bool>('guestSend', {'line': line})) ?? false;

  static Future<void> guestStop() async => _ch.invokeMethod('guestStop');
}
