import 'package:flutter/material.dart';
import 'theme.dart';

class VraPage extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const VraPage({super.key, required this.title, required this.children});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(title)),
        body: ListView(padding: const EdgeInsets.all(16), children: children),
      );
}

class VCard extends StatelessWidget {
  final String? title;
  final List<Widget> children;
  final Color? border;
  const VCard({super.key, this.title, required this.children, this.border});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: VraColors.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: (border ?? VraColors.cyan).withOpacity(0.25)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (title != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(title!,
                  style: const TextStyle(
                      fontSize: 16, fontWeight: FontWeight.w700, color: VraColors.cyan)),
            ),
          ...children,
        ]),
      );
}

class Row2 extends StatelessWidget {
  final String k, v;
  const Row2(this.k, this.v, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(flex: 4, child: Text(k, style: const TextStyle(color: VraColors.muted))),
          Expanded(flex: 5, child: Text(v)),
        ]),
      );
}

class Note extends StatelessWidget {
  final String text;
  final Color color;
  const Note(this.text, {super.key, this.color = VraColors.warn});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.10),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Text(text),
      );
}
