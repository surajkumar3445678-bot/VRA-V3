import 'package:flutter/material.dart';
import 'app_state.dart';
import 'screens.dart';
import 'theme.dart';

void main() => runApp(const VraApp());

class VraApp extends StatelessWidget {
  const VraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'VRA',
        debugShowCheckedModeBanner: false,
        theme: vraTheme(),
        home: SplashScreen(AppState()),
      );
}
