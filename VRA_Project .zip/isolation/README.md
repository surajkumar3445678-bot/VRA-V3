# isolation
Implemented: clipboard and shared-folder policy flags (default off), stored locally.
Designed: guest gets only its own app-private disk image; no host paths mounted unless the shared-folder flag is on.
Fingerprints that remain visible to a guest: virtual device names, emulated CPU model, timing. VRA does not spoof them.
