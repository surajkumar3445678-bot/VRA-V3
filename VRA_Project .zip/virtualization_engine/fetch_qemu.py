#!/usr/bin/env python3
"""Fetch a prebuilt aarch64 QEMU (Termux build) and repackage it as Android jniLibs.

Usage: fetch_qemu.py <android_main_dir>   (e.g. android/app/src/main)
Result:
  <main>/jniLibs/arm64-v8a/libqemu.so        the qemu-system-aarch64 binary
  <main>/jniLibs/arm64-v8a/lib*.so            its shared-library dependencies (renamed to lib*.so)
  <main>/assets/qemu_libmap.txt               lines "original_name=renamed_name" so the app can
                                              recreate the original names as symlinks at runtime.
QEMU is GPLv2. Source: https://www.qemu.org/ and Termux package sources.
"""
import os, re, shutil, subprocess, sys, tempfile, urllib.request

BASE = "https://packages.termux.dev/apt/termux-main/"
INDEX = BASE + "dists/stable/main/binary-aarch64/Packages"
ROOT_PKG = "qemu-system-aarch64-headless"
SKIP = {"termux-tools", "termux-exec", "termux-core", "apt", "dpkg", "bash", "coreutils"}
PREFIX = "data/data/com.termux/files/usr"


def get(url):
    with urllib.request.urlopen(url, timeout=120) as r:
        return r.read()


def parse_index(text):
    pk = {}
    for block in text.split("\n\n"):
        f = {}
        for line in block.splitlines():
            if ": " in line and not line.startswith(" "):
                k, v = line.split(": ", 1)
                f[k] = v
        if "Package" in f:
            pk[f["Package"]] = f
    return pk


def deps_of(f):
    out = []
    for part in f.get("Depends", "").split(","):
        name = part.split("|")[0].strip()
        name = re.sub(r"\s*\(.*\)", "", name).strip()
        if name:
            out.append(name)
    return out


def closure(pk, root):
    seen, todo = [], [root]
    while todo:
        n = todo.pop()
        if n in seen or n in SKIP or n not in pk:
            continue
        seen.append(n)
        todo.extend(deps_of(pk[n]))
    return seen


def is_elf(path):
    with open(path, "rb") as fh:
        return fh.read(4) == b"\x7fELF"


def renamed(real_name):
    if real_name.startswith("lib") and real_name.endswith(".so"):
        return real_name
    return "lib" + re.sub(r"[^A-Za-z0-9_+-]", "_", real_name) + ".so"


def main():
    main_dir = sys.argv[1]
    jni = os.path.join(main_dir, "jniLibs", "arm64-v8a")
    assets = os.path.join(main_dir, "assets")
    os.makedirs(jni, exist_ok=True)
    os.makedirs(assets, exist_ok=True)

    pk = parse_index(get(INDEX).decode("utf-8", "replace"))
    if ROOT_PKG not in pk:
        sys.exit("package %s not found in Termux index" % ROOT_PKG)
    pkgs = closure(pk, ROOT_PKG)
    print("packages:", pkgs)

    work = tempfile.mkdtemp()
    libmap = {}
    got_binary = False
    for name in pkgs:
        deb = os.path.join(work, name + ".deb")
        with open(deb, "wb") as fh:
            fh.write(get(BASE + pk[name]["Filename"]))
        dest = os.path.join(work, "x_" + name)
        subprocess.check_call(["dpkg-deb", "-x", deb, dest])
        if name == ROOT_PKG:
            binp = os.path.join(dest, PREFIX, "bin", "qemu-system-aarch64")
            if os.path.isfile(binp):
                shutil.copy(binp, os.path.join(jni, "libqemu.so"))
                got_binary = True
        libdir = os.path.join(dest, PREFIX, "lib")
        if not os.path.isdir(libdir):
            continue
        for fn in sorted(os.listdir(libdir)):
            p = os.path.join(libdir, fn)
            if ".so" not in fn or os.path.isdir(p):
                continue
            real = os.path.realpath(p)
            if not os.path.isfile(real) or not is_elf(real):
                continue
            new = renamed(os.path.basename(real))
            target = os.path.join(jni, new)
            if not os.path.exists(target):
                shutil.copy(real, target)
            libmap[fn] = new

    if not got_binary:
        sys.exit("qemu-system-aarch64 binary not found in package")
    with open(os.path.join(assets, "qemu_libmap.txt"), "w") as fh:
        for k in sorted(libmap):
            fh.write("%s=%s\n" % (k, libmap[k]))
    total = sum(os.path.getsize(os.path.join(jni, x)) for x in os.listdir(jni))
    print("libs: %d  total size: %.1f MB" % (len(os.listdir(jni)), total / 1e6))


if __name__ == "__main__":
    main()
