#!/bin/sh
# PID 1 of the VRA Linux guest. Runs entirely inside the guest (RAM only, no network).
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
export TERM=dumb
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /tmp /run
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp
hostname vra-guest
echo
echo "=== VRA guest ready ==="
echo "Kernel: $(uname -r) (the guest's own kernel, not your phone's)"
echo "You are $(id -un) (uid $(id -u)) inside the guest only."
echo "Type exit to shut the guest down."
echo
export PS1='vra-guest # '
setsid sh -c 'sh </dev/ttyAMA0 >/dev/ttyAMA0 2>&1'
echo "Shell ended. Powering off."
poweroff -f
